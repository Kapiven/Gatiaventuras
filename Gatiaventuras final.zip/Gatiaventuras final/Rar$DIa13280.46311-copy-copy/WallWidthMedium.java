import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WallWidthMedium here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WallWidthMedium extends Walls
{
    /**
     * Act - do whatever the WallWidthMedium wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public WallWidthMedium()
    {
        getImage().scale(getImage().getWidth() * 7 , getImage().getHeight());
    }
    public void act()
    {
        // Add your action code here.
    }
}
