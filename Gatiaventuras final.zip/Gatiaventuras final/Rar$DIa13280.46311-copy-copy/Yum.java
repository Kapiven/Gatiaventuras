import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Yum here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Yum extends Actor
{
    /**
     * Act - do whatever the Yum wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Yum()
    {
        getImage().scale(getImage().getWidth() / 20 , getImage().getHeight() / 20 );
    }
    public void act()
    {
        // Add your action code here.
    }
}
